import React from 'react'
import BannerView from '../Banner/BannerView'
import ServiceView from '../Service/ServiceView'
import Testimonial from '../Testimonial/Testimonial'
import Companies from '../../Companies/Companies'

function Home() {
  return (
    <>
    <BannerView/> 
    <ServiceView/>
    <Testimonial/>
    <Companies/> 
    </>
  )
}

export default Home
