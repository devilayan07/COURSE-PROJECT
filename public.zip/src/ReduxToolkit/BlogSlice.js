import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../Component/Helper/Helper";

export const fetchBlog=createAsyncThunk("/user/allBlog",async()=>{
    const response=await axiosInstance.get("/allBlog")
    return response.data
})

export const fetchCategory=createAsyncThunk("/user/category",async()=>{
    const response=await axiosInstance.get("/showallcategory")
    return response.data
})

export const fetchSearch=createAsyncThunk("/user/serach",async(output)=>{
    const response=await axiosInstance.get(`/search/${output}`)
    console.log(response.data)
    return response.data
})
const BlogSlice=createSlice({
    name:"blog",
    initialState:{
        isLoading:false,
        blog:[],
        category:[],
        
        error:null,
        status:"idle"
    },

    extraReducers:(builder)=>{
        builder.addCase(fetchBlog.pending,(state)=>{
            state.isLoading=true
        })
        builder.addCase(fetchBlog.fulfilled,(state,action)=>{
            state.isLoading=false
            state.blog=action.payload
            state.error=null
        })
        builder.addCase(fetchBlog.rejected,(state,action)=>{
            state.isLoading=false
            state.blog=[]
            state.error=action.error.message
        })
        builder.addCase(fetchCategory.pending,(state)=>{
            state.isLoading=true
        })
        builder.addCase(fetchCategory.fulfilled,(state,action)=>{
            state.isLoading=false
            state.category=action.payload
            state.error=null
        })
        builder.addCase(fetchCategory.rejected,(state,action)=>{
            state.isLoading=false
            state.category=[]
            state.error=action.error.message
        })
        builder.addCase(fetchSearch.pending,(state)=>{
            state.status="loading"
        })
        builder.addCase(fetchSearch.fulfilled,(state,action)=>{
            state.status="idle"
            state.blog=action.payload
            console.log(action.payload)
        })
        builder.addCase(fetchSearch.rejected,(state,action)=>{
            state.status="error"
        })
    }
})

export default BlogSlice.reducer