import './App.css';
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
import Registration from './Component/AUTH/Registration';
import Login from './Component/AUTH/Login';
import Header from './LAYOUT/Header/Header';
import Home from './Component/CMS/Home/Home';
import About from './Component/CMS/About/About';
import Course from './Component/CMS/Course/Course';
import Blog from './Component/CMS/Blog/Blog';
import { useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { check_token } from './ReduxToolkit/AuthSlice';
import ApplyCourse from './Component/CMS/ApplyCourse/ApplyCourse';


function App() {
  const dispatch=useDispatch()

  useEffect(()=>{
    dispatch(check_token())
  })
  return (
    <div className="App">
      <Router>
        <Header/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/registration' element={<Registration/>}/>
          <Route path="/login" element={<Login/>}/>
          <Route path='/about' element={<About/>}/>
          <Route path='/course' element={<Course/>}/>
          <Route path="/courses/:id" element={<ApplyCourse/>}/>
          <Route path='/blog' element={<Blog/>}/>


        </Routes>
      </Router>
    </div>
  );
}

export default App;
